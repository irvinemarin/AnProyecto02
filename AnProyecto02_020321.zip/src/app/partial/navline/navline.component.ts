import {Component, OnInit} from '@angular/core';
import {ThemePalette} from '@angular/material/core';

@Component({
  selector: 'app-navline',
  templateUrl: './navline.component.html',
  styleUrls: ['./navline.component.css']
})
export class NavlineComponent implements OnInit {

  ngOnInit(): void {
  }

}
